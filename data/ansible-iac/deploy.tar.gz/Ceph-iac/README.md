# ceph-deploy-ansible

