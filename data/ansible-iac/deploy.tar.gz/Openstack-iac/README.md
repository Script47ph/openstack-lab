### NOTE
- Buat cluster ceph sebelum eksekusi playbook ini.
- Development menggunakan ceph-ansible untuk bootstrap cluster Ceph.
- Cinder set ceph permission

### Environment
```
6 server nodes: 3 (controller+compute+storage) nodes, 3 (compute+storage) nodes

```
